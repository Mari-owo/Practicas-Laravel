<?php
use App\Http\Controllers\alumnosController;
use App\Http\Controllers\MaestrosController;
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*
$masters = [
    ['name' => 'Sergio Panti'],
    ['name' => 'Rafael Yabur'],
    ['name' => 'Raymundo Romero'],
    ['name' => 'Maria Ignot'],
];*/



//php artisan make:controller MaestrosController ----  CONTROLADOR SIMPLE
//php artisan make:controller MaestrosController -i ----  CONTROLADOR MAS PRO (INVOKE)
//php artisan make:controller AlumnosController -r ----  resource trae todos los metodos 

Route::get('/', function () {
    return view('welcome');
});
Route::view('/adios', 'adios');
Route::view('/welcome', 'welcome');
Route::view('/servicios', 'servicios');
Route::view('/index', 'index');
Route::view('/layout', 'layout');
Route::view('/hola', 'hola');
Route::view('/contacto', 'contacto');

//Route::view('/maestros', 'maestros', ['masters' => $masters])->name('master');
//Route::view('/maestros', 'maestros', compact('masters'))->name('master');

Route::get('/maestros', MaestrosController::class)->name('masters');

Route::get('/alumnos', [alumnosController::class, 'index'])->name('students');