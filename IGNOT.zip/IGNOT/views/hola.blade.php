@extends('layout')
@section('pagina actual')
    Esta es la pagina de hola
    @endsection
@section('conteidoPrincipal')
 <h2>pagina hola soy aaron</h2>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Et magni maiores libero ipsam. Commodi asperiores eius reiciendis, doloribus expedita maiores eveniet provident aliquam eos fugiat sint minima repudiandae vitae minus?</p>

@endsection
@section('numeroDePagina')
    <h3>numero pagina 1</h3>
@endsection