@extends('layout')
@section('paginaActual')
    Pagina de alumnos
@endsection

@section('contenidoPrincipal')
    <h3>Lista de alumnos de Ingenieria en Programación</h3>
    @foreach ($students as $alumno) <!--coleccion que vas a convertir como item -->
        <h3>{{$alumno['name']}}</h3>
    @endforeach
@endsection