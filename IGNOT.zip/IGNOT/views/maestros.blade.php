@extends('layout')
@section('paginaActual')
    Pagina de maestros
@endsection

@section('contenidoPrincipal')
    <h3>Lista de maestros de Ingenieria en Programación</h3>
    @foreach ($masters as $master) <!--coleccion que vas a convertir como item -->
        <h3>{{$master['name']}}</h3>
    @endforeach
@endsection